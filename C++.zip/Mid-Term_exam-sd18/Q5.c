#include <stdio.h>
#include <stdlib.h>
int mod(int, int);
Q5()
{
	int x = 17;
	int y = 5;
	printf("mod(%d,%d)=%d\n", x, y, mod(x, y));

}
int mod(int x, int y)
{
	return x%y;
}
