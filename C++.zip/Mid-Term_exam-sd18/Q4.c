#include<stdio.h>
#include<stdlib.h>
int swap(int *i, int *j);
Q4()
{
	int x, y;
	printf("�п�J2�Ʀr:\n");
	scanf("%d%d", &x, &y);
	printf("x=%d,y=%d", x, y);
	swap(&x, &y);
	printf("�洫:x=%d,y=%d", x, y);

}
swap(int *i, int *j)
{
	int swap = *i;
	*i = *j;
	*j = swap;
}