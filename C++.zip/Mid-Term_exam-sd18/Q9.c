#include <stdio.h>
#include <stdlib.h>
Q9()
{
	int i = 0;
	char str[50];
	printf("��J�@��^��:");
	scanf("%s", &str);

	while (str[i] != '\0')
	{
		if (str[i] > 65 && str[i] <= 90)
			str[i] += 32;
		
		i++;
	}
		printf("�ഫ�p�g�� = %s", str);
	

}