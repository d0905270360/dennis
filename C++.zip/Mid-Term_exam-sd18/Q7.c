#include <stdio.h>
#include <stdlib.h>
double f(double);
Q7()
{
	printf("(-3.2)=%.4f\n", f(-3.2));
	printf("(-2.1)=%.4f\n", f(-2.1));
	printf("(-0)=%.4f\n", f(0));
	printf("(-2.1)=%.4f\n", f(2.1));

}
double f(double x)
{
return( 3 * x*x*x + 2 * x - 1) ;
}
