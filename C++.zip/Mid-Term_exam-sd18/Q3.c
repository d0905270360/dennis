#include<stdio.h>
#include<stdlib.h>
Q3()
{
	int a[10];
	int *arr = &a;
	int i, j;
	for (i = 0; i <= 9; i++)
	{
		printf("�п�Jarr[%d]", i);
		scanf("%d", &a[i]);
		printf("a[%d]=%d...&=%p\n", i, (*(arr + i)), (arr + i));
	}
	
}