#include<stdio.h>
#include<stdlib.h>
Q1()
{
	int i;
	int arr[5] = { 34,76,33,42,76 };
	printf("34,76,33,42,76");
	for (i = 0; i < 5; i++)
		*(arr + i) += 10;
	printf("\n+10�ᬰ");
	for (i = 0; i < 5; i++)
		printf("%d", arr[i]);

}