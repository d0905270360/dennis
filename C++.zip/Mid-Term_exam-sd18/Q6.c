#include<stdio.h>
#include<stdlib.h>
int cub(int x), x;
Q6()
{
	x = 5;
	cub(x);
	printf("x^5=%d", cub(x));
	
}
int cub(int x)
{
	x = x*x*x*x*x*x;
	return x;
}