#include <stdio.h>
#include <stdlib.h>
#include"c.h"

void Q1();
void Q2();
void Q3();
void Q4();
void Q5();
void Q6();
void Q7();
//void Q8();
void Q9();
void Q10();


void main()
{
	int input;
	_Bool flag = 1;
	while (flag)
	{
		printf("1.�Ĥ@�D\n");
		printf("2.�ĤG�D\n");
		printf("3.�ĤT�D\n");
		printf("4.�ĥ|�D\n");
		printf("5.�Ĥ��D\n");
		printf("6.�Ĥ��D\n");
		printf("7.�ĤC�D\n");
		printf("8.�ĤK�D�S�g\n");
		printf("9.�ĤE�D\n");
		printf("10.�ĤQ�D\n");
		printf("------------------\n");
		printf("�п�J�n���檺�d��?  1~8 ��'0'�Y�i��������!  ?");
		scanf("%d", &input);

		switch (input)
		{
		case 1:
			Q1();
			break;
		case 2:
			Q2();
			break;
		case 3:
			Q3();
			break;
		case 4:
			Q4();
			break;
		case 5:
			Q5();
			break;
		case 6:
			Q6();
			break;
		case 7:
			Q7();
			break;
		case 8:
			//Q8();
			break;
		case 9:
			Q9();
			break;
		case 10:
			Q10();
			break;
		default:
			break;
		}

		system("pause");
		system("cls");
	}
}