#include <stdio.h>
#include <stdlib.h>
void square(int *arr);
Q2()
{
	int i, a[10] = { 1,2,3,4,5,6,7,8,9,10 };

	printf("�}�C1~10:");
	for (i = 0; i<10; i++)
		printf("%d ", a[i]);
	square(a);

	printf("\n�����=");
	for (i = 0; i<10; i++)
		printf("%d ", a[i]);


}
void square(int *arr)
{
	int i;
	for (i = 0; i<10; i++)
		*(arr + i) = (*(arr + i))*(*(arr + i));
}