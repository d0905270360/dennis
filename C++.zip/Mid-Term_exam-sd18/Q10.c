#include <stdio.h>
#include <stdlib.h>
Q10()
{
	char str[100];
	int n = 0, a = 0, e = 0, i = 0, o = 0, u = 0;
	printf("�п�J�@��^��:");
	scanf("%s", str);

	while (str[n] != '\0')
	{
		switch (str[n])
		{
		case 'a': a++;
			break;
		case 'e': e++;
			break;
		case 'i': i++;
			break;
		case 'o': o++;
			break;
		case 'u': u++;
			break;
		}
		n++;
	}
	printf("a:%d��\n", a);
	printf("e:%d��\n", e);
	printf("i:%d��\n", i);
	printf("o:%d��\n", o);
	printf("u:%d��\n", u);
}