#include <stdio.h>
#include <stdlib.h>
ex1_1()
{
	printf("Hello C!\n");
	printf("Hello World!\n");
}