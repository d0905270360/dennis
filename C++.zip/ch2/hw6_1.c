#include <stdio.h>
#include <stdlib.h>
hw6_1()
{
	int a, b, c;
	printf("�п�J�P�P�����?");
	scanf("%d", &a);
	for (b = a; b >= 1; b--)
	{
		for (c = 1; c <= b - 1; c++)
		{
			printf(" ");
		}
		for (c = a; c >= b; c--)
		{
			printf("*");
		}
		printf("\n");
	}
}