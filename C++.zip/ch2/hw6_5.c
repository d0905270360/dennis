#include <stdio.h>
#include <stdlib.h>
hw6_5()
{
	int a, b, c;
	printf("�п�J�P�P�����?");
	scanf("%d", &a);
	for (b = 1; b <= a; b++)
	{
		for (c = 1; c <= a - b; c++)
		{
			printf(" ");
		}

		for (c = 1; c <= b; c++)
		{
			printf("*");
		}
		for (c = 2; c <= b; c++)
		{
			printf("*");
		}
		printf("\n");
	}
}