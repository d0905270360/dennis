#include <stdio.h>
#include <stdlib.h>
hw6_3()
{
	int a, b, c;
	printf("�п�J�P�P�����?");
	scanf("%d", &a);
	for (b = a; b >= 1; b--)
	{
		for (c = 1; c <= b; c++)
		{
			printf("*");

		}
		printf("\n");
	}
}