#include<iostream>
#include<cstdlib>
extern void ex11_1();
extern void ex11_2();
extern void ex11_3();
extern void ex11_4();
extern void ex11_5();
extern void ex11_6();
extern void ex11_7();
using namespace std;


int main(void) 
{
	int input;

	do {
		system("cls");
		cout<<"-------------------------------------"<<endl;
		cout<<"1.ex11_1" << endl;
		cout<<"-------------------------------------" << endl;
		cout<<"�п�J�n���檺�d��? 1~12,��'0' �h��������!? " << endl;
		cin >> input;

		while (getchar() != '\n');

		switch (input)
		{	
		case 0:
			break;
		case 1:
			ex11_1();
			break;
		case 2:
			ex11_2();
			break;
		case 3:
			ex11_3();
			break;
		case 4:
			//ex12_4();
			break;
		case 5:
			//ex12_5();
			break;
		case 6:
			ex11_6();
			break;
		case 7:
			ex11_7();
			break;
		case 8:
			//ex12_8();
			break;
	    case 9:
		   // ex12_12();
			break;

		case 12:
			//pra12_1();
			break;
		case 13:
			//pra9_2();
			break;
		

		default:
			cout << "��J���Ʀr���b�d��!!" << endl;

			break;
		}
	} while (input != 0);
}