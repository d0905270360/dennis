#include <iostream>
#include <cstdlib>
using namespace std;
void ex11_3(void)
{
	bool bt = true;
	bool bs = 0;
	cout << "sizeof(bt) = " << sizeof(bt) << endl;
	cout << "bs = " << bs << " , bt = " << bt << endl;
	system("pause"); //return(0);
}
