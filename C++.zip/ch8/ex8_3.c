#include <stdio.h>

ex8_3()
{
	int a = 100;
	int *p = &a; //int *p = a;
	int **pp = &p; 	//int **pp = p;
	printf("a=%d, *p=%d, and **pp=%d\n", a, *p, **pp);
	return 0;
}
