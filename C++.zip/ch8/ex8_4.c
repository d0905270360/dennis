#include <stdio.h>
#include <stdlib.h>
ex8_4()
{
	double d;
	double *p = &d;
	double **pp = &p;
	printf("�п�J�@double��: ");
	scanf("%lf", &d);
	printf("a=.2lf=%.2lf, and **pp=%.2lf\n", d, *p, **pp);
	//system("PAUSE");
	//return 0;
}
