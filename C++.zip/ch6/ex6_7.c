#include <stdio.h>
#include <stdlib.h>
int number;        //number�O�@�ӥ����ܼ� 
void output3(void);  // output( )���쫬�ŧi 
ex6_7()
{
	printf("Please enter a number : ");
	scanf("%d", &number);
	output3();
	
}
// �w�qoutput( )
void output3(void)
{
	printf("Number is %d\n", number);
}
