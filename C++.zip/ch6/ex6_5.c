#include<stdio.h>
#include<stdlib.h>
void printstar(int); //printfstar()���쫬�ŧi
ex6_5()
{
	int num;
	printf("�ATM�n�h�֬P�P:");
	scanf("%d", &num);
	printstar(num);
	
}
void printstar(int n)
{
	int i;
	for (i = 1; i < n; i++)
		printf("��");
	printf("\n");
}